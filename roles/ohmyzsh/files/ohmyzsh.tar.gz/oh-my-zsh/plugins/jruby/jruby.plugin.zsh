# Aliases
alias jrspec='jruby --debug -S rspec --debug'
alias jprofile='jruby --profile.api -S rspec'
alias jexec='jruby -S'
